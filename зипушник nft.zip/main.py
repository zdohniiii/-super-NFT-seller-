import sqlite3
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, session, flash
import os
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_very_secret_key_here'
app.config['UPLOAD_FOLDER'] = 'data/images'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

# Создаем папки если их нет
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('data', exist_ok=True)


def get_db_connection():
    conn = sqlite3.connect('data/database.db')
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Инициализация базы данных"""
    conn = get_db_connection()

    # Таблица пользователей
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            balance INTEGER DEFAULT 100
        )
    ''')

    # Таблица NFT
    conn.execute('''
        CREATE TABLE IF NOT EXISTS nfts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            image_path TEXT NOT NULL,
            price INTEGER NOT NULL,
            uploader_id INTEGER NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (uploader_id) REFERENCES users(id)
        )
    ''')

    # Таблица владения NFT
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_nfts (
            user_id INTEGER NOT NULL,
            nft_id INTEGER NOT NULL,
            purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, nft_id),
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (nft_id) REFERENCES nfts(id)
        )
    ''')

    conn.commit()
    conn.close()


init_db()


@app.route('/')
def home():
    """Главная страница"""
    conn = get_db_connection()
    nfts = conn.execute('''
        SELECT nfts.*, users.username as uploader 
        FROM nfts JOIN users ON nfts.uploader_id = users.id
        ORDER BY nfts.created_at DESC
    ''').fetchall()
    conn.close()

    message = request.args.get('message')
    return render_template('home.html', nfts=nfts, message=message)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('home'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not username or not password:
            flash('Please fill in all fields', 'error')
            return redirect(url_for('login'))

        conn = get_db_connection()
        try:
            # Проверяем по username или email
            user = conn.execute(
                'SELECT * FROM users WHERE username = ? OR email = ?',
                (username, username)
            ).fetchone()

            if not user:
                flash('User not found. Please check your username/email', 'error')
                return redirect(url_for('login'))

            if not check_password_hash(user['password'], password):
                flash('Incorrect password', 'error')
                return redirect(url_for('login'))

            # Успешная авторизация
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['email'] = user['email']
            session['balance'] = user['balance']

            flash('Login successful!', 'success')
            return redirect(url_for('home'))

        finally:
            conn.close()

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('home'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        # Валидация
        errors = []
        if not all([username, email, password, confirm_password]):
            errors.append('All fields are required')
        if len(username) < 3:
            errors.append('Username must be at least 3 characters')
        if len(password) < 6:
            errors.append('Password must be at least 6 characters')
        if password != confirm_password:
            errors.append('Passwords do not match')
        if not email.count('@') == 1:
            errors.append('Invalid email format')

        if errors:
            for error in errors:
                flash(error, 'error')
            return redirect(url_for('register'))

        conn = get_db_connection()
        try:
            # Проверка существующего пользователя
            if conn.execute('SELECT id FROM users WHERE username = ?', (username,)).fetchone():
                flash('Username already taken', 'error')
                return redirect(url_for('register'))

            if conn.execute('SELECT id FROM users WHERE email = ?', (email,)).fetchone():
                flash('Email already registered', 'error')
                return redirect(url_for('register'))

            # Создание пользователя
            conn.execute(
                'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
                (username, email, generate_password_hash(password))
            )
            conn.commit()

            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))

        except Exception as e:
            flash('Registration error: ' + str(e), 'error')
            return redirect(url_for('register'))

        finally:
            conn.close()

    return render_template('register.html')


@app.route('/logout')
def logout():
    """Выход из системы"""
    session.clear()
    return redirect(url_for('home'))


@app.route('/nft/add', methods=['GET', 'POST'])
def add_nft():
    """Добавление нового NFT"""
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        price = int(request.form['price'])
        image = request.files['image']

        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(image_path)

            conn = get_db_connection()
            conn.execute(
                'INSERT INTO nfts (title, description, image_path, price, uploader_id) VALUES (?, ?, ?, ?, ?)',
                (title, description, f"/data/images/{filename}", price, session['user_id']))
            conn.commit()
            conn.close()

            return redirect(url_for('home'))

    return render_template('add_nft.html')


@app.route('/buy', methods=['POST'])
def buy_nft():
    """Покупка NFT"""
    if 'user_id' not in session:
        return {'error': 'Not logged in'}, 401

    nft_id = request.json.get('nftId')
    if not nft_id:
        return {'error': 'No NFT specified'}, 400

    conn = get_db_connection()

    try:
        # Получаем информацию о NFT
        nft = conn.execute(
            'SELECT * FROM nfts WHERE id = ?', (nft_id,)
        ).fetchone()

        if not nft:
            return {'error': 'NFT not found'}, 404

        # Проверяем, что пользователь не покупает свой же NFT
        if nft['uploader_id'] == session['user_id']:
            return {'error': 'Cannot buy your own NFT'}, 400

        # Проверяем баланс
        user = conn.execute(
            'SELECT * FROM users WHERE id = ?', (session['user_id'],)
        ).fetchone()

        if user['balance'] < nft['price']:
            return {'error': 'Insufficient funds'}, 400

        # Проверяем, что у пользователя еще нет этого NFT
        existing = conn.execute(
            'SELECT * FROM user_nfts WHERE user_id = ? AND nft_id = ?',
            (session['user_id'], nft_id)
        ).fetchone()

        if existing:
            return {'error': 'Already owned'}, 400

        # Выполняем транзакцию
        # 1. Уменьшаем баланс покупателя
        conn.execute(
            'UPDATE users SET balance = balance - ? WHERE id = ?',
            (nft['price'], session['user_id'])
        )

        # 2. Увеличиваем баланс продавца
        conn.execute(
            'UPDATE users SET balance = balance + ? WHERE id = ?',
            (nft['price'], nft['uploader_id'])
        )

        # 3. Добавляем запись о владении
        conn.execute(
            'INSERT INTO user_nfts (user_id, nft_id) VALUES (?, ?)',
            (session['user_id'], nft_id)
        )

        conn.commit()

        # Обновляем баланс в сессии
        session['balance'] = user['balance'] - nft['price']

        return {'message': 'Purchase successful!'}

    except Exception as e:
        conn.rollback()
        return {'error': str(e)}, 500
    finally:
        conn.close()


@app.route('/profile')
def profile():
    """Страница профиля"""
    if 'user_id' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()

    # Получаем загруженные пользователем NFT
    uploaded = conn.execute('''
        SELECT * FROM nfts WHERE uploader_id = ?
    ''', (session['user_id'],)).fetchall()

    # Получаем купленные NFT
    purchased = conn.execute('''
        SELECT nfts.* FROM user_nfts
        JOIN nfts ON user_nfts.nft_id = nfts.id
        WHERE user_nfts.user_id = ?
    ''', (session['user_id'],)).fetchall()

    conn.close()

    return render_template(
        'profile.html',
        uploaded_nfts=uploaded,
        user_nfts=purchased
    )


@app.route('/nft/<int:nft_id>')
def nft_detail(nft_id):
    """Страница с детальной информацией о NFT"""
    conn = get_db_connection()

    # Получаем информацию о NFT и владельце
    nft = conn.execute('''
        SELECT nfts.*, users.username as uploader_username, 
               users.email as uploader_email
        FROM nfts 
        JOIN users ON nfts.uploader_id = users.id
        WHERE nfts.id = ?
    ''', (nft_id,)).fetchone()

    if not nft:
        flash('NFT not found', 'error')
        return redirect(url_for('home'))

    conn.close()
    return render_template('nft_detail.html', nft=nft)


@app.route('/user/<username>')
def user_profile(username):
    """Публичный профиль пользователя"""
    conn = get_db_connection()

    # Информация о пользователе
    user = conn.execute(
        'SELECT id, username, email FROM users WHERE username = ?',
        (username,)
    ).fetchone()

    if not user:
        flash('User not found', 'error')
        return redirect(url_for('home'))

    # NFT загруженные пользователем
    uploaded_nfts = conn.execute('''
        SELECT * FROM nfts WHERE uploader_id = ?
        ORDER BY created_at DESC
    ''', (user['id'],)).fetchall()

    conn.close()

    return render_template('public_profile.html',
                           user=user,
                           uploaded_nfts=uploaded_nfts)

@app.route('/data/images/<filename>')
def serve_image(filename):
    """Отдача изображений"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


def allowed_file(filename):
    """Проверка расширения файла"""
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']


if __name__ == '__main__':
    app.run(debug=True)
